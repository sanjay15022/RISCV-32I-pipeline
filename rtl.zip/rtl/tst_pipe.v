
`timescale 1ns/1ps

module tst_unwanted_stall;

reg clk;
integer stall_count;
integer pass_count;
integer fail_count;
integer i;

main_pipe uut (
    .clk(clk)
);

initial begin
    clk = 0;
    stall_count = 0;
    pass_count = 0;
    fail_count = 0;

    $display("\n==========================================");
    $display("       RV32I UNWANTED STALL TEST");
    $display("==========================================");
end

always #5 clk = ~clk;

// Count every cycle in which the hazard unit asserts stall
always @(posedge clk) begin
    if (uut.stall === 1'b1)
        stall_count = stall_count + 1;
end

task check_reg;
    input [4:0] reg_num;
    input [31:0] expected;
    input [200*8:1] test_name;
    begin
        if (uut.register1.register[reg_num] === expected) begin
            $display("PASS: %0s = %h",
                test_name, uut.register1.register[reg_num]);
            pass_count = pass_count + 1;
        end
        else begin
            $display("FAIL: %0s expected %h, got %h",
                test_name, expected,
                uut.register1.register[reg_num]);
            fail_count = fail_count + 1;
        end
    end
endtask

initial begin

    // Allow the pipeline to execute and drain
    repeat (50) @(posedge clk);
    #1;

    $display("\n========== REGISTER CHECKS ==========");

    check_reg(1,  32'd64,       "x1 base address");
    check_reg(2,  32'd42,       "x2 initial value");
    check_reg(5,  32'd42,       "x5 loaded value");
    check_reg(6,  32'd42,       "x6 loaded value");
    check_reg(8,  32'd42,       "x8 loaded value");
    check_reg(9,  32'd42,       "x9 loaded value");

    check_reg(10, 32'd5,        "x10 ADDI immediate");
    check_reg(11, 32'h00030000, "x11 LUI");
    check_reg(12, 32'h00048028, "x12 AUIPC");
    check_reg(13, 32'd42,       "x13 loaded value");
    check_reg(14, 32'd1,        "x14 independent ADDI");
    check_reg(15, 32'd84,       "x15 dependent ADD");
    check_reg(16, 32'h00800000, "x16 LUI");
    check_reg(17, 32'd0,        "x17 ADDI");
    check_reg(18, 32'd1,        "x18 ADDI");

    $display("\n========== MEMORY CHECKS ==========");

    if ({uut.dmem1.dmemory[67],
         uut.dmem1.dmemory[66],
         uut.dmem1.dmemory[65],
         uut.dmem1.dmemory[64]} === 32'd42) begin
        $display("PASS: MEM[64] = 0000002a");
        pass_count = pass_count + 1;
    end
    else begin
        $display("FAIL: MEM[64] expected 0000002a");
        fail_count = fail_count + 1;
    end

    $display("\n========== STALL CHECK ==========");

    $display("Unnecessary stall cycles = %0d", stall_count);

    if (stall_count == 0) begin
        $display("PASS: No unnecessary stalls detected");
        pass_count = pass_count + 1;
    end
    else begin
        $display("FAIL: Unnecessary stalls detected");
        fail_count = fail_count + 1;
    end

    $display("\n==========================================");
    $display("TOTAL PASS: %0d", pass_count);
    $display("TOTAL FAIL: %0d", fail_count);
    $display("STALL CYCLES: %0d", stall_count);
    $display("==========================================");

    $finish;
end

endmodule
